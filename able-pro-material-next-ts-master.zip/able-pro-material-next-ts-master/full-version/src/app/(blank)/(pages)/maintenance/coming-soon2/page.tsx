// PROJECT IMPORTS
import ComingSoon2Page from 'views/maintenance/ComingSoon2';

// ==============================|| COMING SOON ||============================== //

function ComingSoon() {
  return <ComingSoon2Page />;
}

export default ComingSoon;
