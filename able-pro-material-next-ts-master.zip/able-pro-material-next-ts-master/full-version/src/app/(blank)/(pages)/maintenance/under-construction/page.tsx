// PROJECT IMPORTS
import UnderConstructionPage from 'views/maintenance/UnderConstruction';

// ==============================|| UNDER CONSTRUCTION ||============================== //

function UnderConstruction() {
  return <UnderConstructionPage />;
}

export default UnderConstruction;
