// PROJECT IMPORTS
import Error404Page from 'views/maintenance/Error404';

// ==============================|| ERROR 404 ||============================== //

function Error404() {
  return <Error404Page />;
}

export default Error404;
