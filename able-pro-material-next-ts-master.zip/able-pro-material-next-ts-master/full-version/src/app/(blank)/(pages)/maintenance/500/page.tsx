// PROJECT IMPORTS
import Error500Page from 'views/maintenance/Error500';

// ==============================|| ERROR 500 ||============================== //

function Error500() {
  return <Error500Page />;
}

export default Error500;
