// PROJECT IMPORTS
import UnderConstruction2page from 'views/maintenance/UnderConstruction2';

// ==============================|| UNDER CONSTRUCTION ||============================== //

function UnderConstruction() {
  return <UnderConstruction2page />;
}

export default UnderConstruction;
