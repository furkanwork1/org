// PROJECT IMPORTS
import ComingSoonPage from 'views/maintenance/ComingSoon';

// ==============================|| COMING SOON ||============================== //

function ComingSoon() {
  return <ComingSoonPage />;
}

export default ComingSoon;
