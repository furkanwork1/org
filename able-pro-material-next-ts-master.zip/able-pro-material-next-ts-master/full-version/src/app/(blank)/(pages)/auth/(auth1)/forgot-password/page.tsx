// PROJECT IMPORTS
import ForgotPasswordPage from 'views/auth/auth1/ForgotPassword';

// ================================|| FORGOT PASSWORD ||================================ //

const ForgotPassword = () => {
  return <ForgotPasswordPage />;
};

export default ForgotPassword;
