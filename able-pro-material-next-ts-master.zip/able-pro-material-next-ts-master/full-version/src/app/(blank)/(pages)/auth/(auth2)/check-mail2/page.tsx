// PROJECT IMPORTS
import CheckMailPage from 'views/auth/auth2/CheckMail';

// ================================|| CHECK MAIL ||================================ //

const CheckMail = () => {
  return <CheckMailPage />;
};

export default CheckMail;
