// PROJECT IMPORTS
import LoginPage from 'views/auth/auth1/Login';

// ================================|| LOGIN ||================================ //

const Login = () => {
  return <LoginPage />;
};

export default Login;
