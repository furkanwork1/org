// PROJECT IMPORTS
import RegisterPage from 'views/auth/auth1/Register';

// ================================|| REGISTER ||================================ //

const Register = () => {
  return <RegisterPage />;
};

export default Register;
