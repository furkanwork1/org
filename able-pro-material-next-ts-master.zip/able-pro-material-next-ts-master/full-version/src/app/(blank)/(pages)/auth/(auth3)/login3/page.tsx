// PROJECT IMPORTS
import Login3Page from 'views/auth/auth3/Login';

// ================================|| LOGIN ||================================ //

const Login3 = () => {
  return <Login3Page />;
};

export default Login3;
