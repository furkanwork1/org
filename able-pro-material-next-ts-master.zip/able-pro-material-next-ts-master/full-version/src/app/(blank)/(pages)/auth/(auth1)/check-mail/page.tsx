// PROJECT IMPORTS
import CheckMailPage from 'views/auth/auth1/CheckMail';

// ================================|| CHECK MAIL ||================================ //

const CheckMail = () => {
  return <CheckMailPage />;
};

export default CheckMail;
