// PROJECT IMPORTS
import ResetPasswordPage from 'views/auth/auth1/ResetPassword';

// ================================|| RESET PASSWORD ||================================ //

const ResetPassword = () => {
  return <ResetPasswordPage />;
};

export default ResetPassword;
