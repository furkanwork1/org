// PROJECT IMPORTS
import ForgotPasswordPage from 'views/auth/auth2/ForgotPassword';

// ================================|| FORGOT PASSWORD ||================================ //

const ForgotPassword = () => {
  return <ForgotPasswordPage />;
};

export default ForgotPassword;
