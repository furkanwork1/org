// PROJECT IMPORTS
import Login2Page from 'views/auth/auth2/Login';

// ================================|| LOGIN ||================================ //

const Login2 = () => {
  return <Login2Page />;
};

export default Login2;
