// PROJECT IMPORTS
import CodeVerificationPage from 'views/auth/auth2/CodeVerification';

// ================================|| CODE VERIFICATION ||================================ //

const CodeVerification = () => {
  return <CodeVerificationPage />;
};

export default CodeVerification;
