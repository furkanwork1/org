// PROJECT IMPORTS
import CodeVerificationPage from 'views/auth/auth1/CodeVerification';

// ================================|| CODE VERIFICATION ||================================ //

const CodeVerification = () => {
  return <CodeVerificationPage />;
};

export default CodeVerification;
