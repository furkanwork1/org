// PROJECT IMPORTS
import RegisterPage from 'views/auth/auth2/Register';

// ================================|| REGISTER ||================================ //

const Register = () => {
  return <RegisterPage />;
};

export default Register;
