// PROJECT IMPORTS
import OrgChartPage from 'views/charts/OrgChart';

// ==============================|| ORGANIZATION CHARTS ||============================== //

const OrgChart = () => {
  return <OrgChartPage />;
};

export default OrgChart;
