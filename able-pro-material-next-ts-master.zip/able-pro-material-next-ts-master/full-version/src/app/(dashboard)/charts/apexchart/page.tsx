// PROJECT IMPORTS
import Apexcharts from 'views/charts/Apexchart';

// ==============================|| APEX CHARTS ||============================== //

const Apexchart = () => {
  return <Apexcharts />;
};

export default Apexchart;
