// PROJECT IMPORTS
import FilteringTable from 'views/forms-tables/tables/react-table/FilteringTable';

// ==============================|| REACT TABLE - FILTERING ||============================== //

const Filtering = () => {
  return <FilteringTable />;
};

export default Filtering;
