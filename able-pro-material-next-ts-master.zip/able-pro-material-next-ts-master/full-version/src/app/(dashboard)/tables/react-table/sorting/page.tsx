// PROJECT IMPORTS
import SortingTable from 'views/forms-tables/tables/react-table/SortingTable';

// ==============================|| REACT TABLE - SORTING ||============================== //

const Sorting = () => {
  return <SortingTable />;
};

export default Sorting;
