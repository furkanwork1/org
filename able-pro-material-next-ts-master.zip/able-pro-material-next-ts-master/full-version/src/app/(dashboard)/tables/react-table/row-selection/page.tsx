// PROJECT IMPORTS
import RowSelectionTable from 'views/forms-tables/tables/react-table/RowSelectionTable';

// ==============================|| REACT TABLE - ROW SELECTION ||============================== //

const RowSelection = () => {
  return <RowSelectionTable />;
};

export default RowSelection;
