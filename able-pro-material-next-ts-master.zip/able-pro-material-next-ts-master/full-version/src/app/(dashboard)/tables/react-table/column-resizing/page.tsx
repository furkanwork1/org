// PROJECT IMPORTS
import ColumnResizingTable from 'views/forms-tables/tables/react-table/ColumnResizingTable';

// ==============================|| REACT TABLE - COLUMN RESIZING ||============================== //

const ColumnResizing = () => {
  return <ColumnResizingTable />;
};

export default ColumnResizing;
