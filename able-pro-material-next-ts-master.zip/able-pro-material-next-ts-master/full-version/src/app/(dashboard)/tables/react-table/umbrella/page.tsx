// PROJECT IMPORTS
import UmbrellaTable from 'views/forms-tables/tables/react-table/UmbrellaTable';

// ==============================|| REACT TABLE - UMBRELLA ||============================== //

const Umbrella = () => {
  return <UmbrellaTable />;
};

export default Umbrella;
