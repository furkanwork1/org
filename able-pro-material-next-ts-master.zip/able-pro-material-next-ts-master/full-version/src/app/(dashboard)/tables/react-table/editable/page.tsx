// PROJECT IMPORTS
import EditableTable from 'views/forms-tables/tables/react-table/EditableTable';

// ==============================|| REACT TABLE - EDITABLE ||============================== //

const Editable = () => {
  return <EditableTable />;
};

export default Editable;
