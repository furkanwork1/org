// PROJECT IMPORTS
import BasicTables from 'views/forms-tables/tables/react-table/BasicTable';

// ==============================|| REACT TABLE - BASIC ||============================== //

const Basic = () => {
  return <BasicTables />;
};

export default Basic;
