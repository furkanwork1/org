// PROJECT IMPORTS
import GroupingTables from 'views/forms-tables/tables/react-table/GroupingTables';

// ==============================|| REACT TABLE - GROUPING ||============================== //

const Grouping = () => {
  return <GroupingTables />;
};

export default Grouping;
