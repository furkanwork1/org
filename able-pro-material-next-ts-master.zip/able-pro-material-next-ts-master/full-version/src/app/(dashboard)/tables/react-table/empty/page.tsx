// PROJECT IMPORTS
import EmptyTables from 'views/forms-tables/tables/react-table/EmptyTable';

// ==============================|| REACT TABLE - EMPTY ||============================== //

const EmptyTableDemo = () => {
  return <EmptyTables />;
};

export default EmptyTableDemo;
