// PROJECT IMPORTS
import StickyTables from 'views/forms-tables/tables/react-table/StickyTables';

// ==============================|| REACT TABLE - STICKY ||============================== //

const Sticky = () => {
  return <StickyTables />;
};

export default Sticky;
