// PROJECT IMPORTS
import ExpandingTables from 'views/forms-tables/tables/react-table/ExpandingTables';

// ==============================|| REACT TABLE - EXPANDING ||============================== //

const Expanding = () => {
  return <ExpandingTables />;
};

export default Expanding;
