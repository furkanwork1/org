// PROJECT IMPORTS
import ColumnHidingTable from 'views/forms-tables/tables/react-table/ColumnHidingTable';

// ==============================|| REACT TABLE - COLUMN HIDING ||============================== //

const ColumnHiding = () => {
  return <ColumnHidingTable />;
};

export default ColumnHiding;
