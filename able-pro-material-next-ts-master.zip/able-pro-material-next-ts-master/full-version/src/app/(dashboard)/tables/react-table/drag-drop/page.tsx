// PROJECT IMPORTS
import DragDropTable from 'views/forms-tables/tables/react-table/DragDropTable';

// ==============================|| REACT TABLE - DRAG & DROP ||============================== //

const DragDrop = () => {
  return <DragDropTable />;
};

export default DragDrop;
