// PROJECT IMPORTS
import PaginationTable from 'views/forms-tables/tables/react-table/PaginationTable';

// ==============================|| REACT TABLE - PAGINATION ||============================== //

const Pagination = () => {
  return <PaginationTable />;
};

export default Pagination;
