// PROJECT IMPORTS
import TableCollapsible from 'views/forms-tables/tables/mui-table/TableCollapsible';

// ==============================|| MUI TABLE - COLLAPSIBLE ||============================== //

export default function Collapsible() {
  return <TableCollapsible />;
}
