// PROJECT IMPORTS
import TableStickyHead from 'views/forms-tables/tables/mui-table/TableStickyHead';

// ==============================|| MUI TABLE - STICKY HEADER ||============================== //

export default function StickyHeadTable() {
  return <TableStickyHead />;
}
