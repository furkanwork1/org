// PROJECT IMPORTS
import TableEnhanced from 'views/forms-tables/tables/mui-table/TableEnhanced';

// ==============================|| TABLE - ENHANCED ||============================== //

export default function EnhancedTable() {
  return <TableEnhanced />;
}
