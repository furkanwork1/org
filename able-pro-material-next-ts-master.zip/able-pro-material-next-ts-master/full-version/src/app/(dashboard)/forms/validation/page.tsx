// PROJECT IMPORTS
import FormsValidationPage from 'views/forms-tables/forms/FormsValidation';

// ==============================|| FORMS VALIDATION - FORMIK ||============================== //

const FormsValidation = () => {
  return <FormsValidationPage />;
};

export default FormsValidation;
