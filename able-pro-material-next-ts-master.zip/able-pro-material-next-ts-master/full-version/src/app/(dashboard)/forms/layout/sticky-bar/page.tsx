// PROJECT IMPORTS
import StickyActionBarPage from 'views/forms-tables/forms/layout/StickyActionBar';

// ==============================|| LAYOUTS - STICKY ACTION BAR ||============================== //

function StickyActionBar() {
  return <StickyActionBarPage />;
}

export default StickyActionBar;
