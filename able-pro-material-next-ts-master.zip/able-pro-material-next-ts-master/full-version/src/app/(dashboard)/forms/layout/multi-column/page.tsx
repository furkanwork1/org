// PROJECT IMPORTS
import ColumnsLayoutsPage from 'views/forms-tables/forms/layout/ColumnsLayouts';

// ==============================|| LAYOUTS -  COLUMNS ||============================== //

function ColumnsLayouts() {
  return <ColumnsLayoutsPage />;
}

export default ColumnsLayouts;
