// PROJECT IMPORTS
import BasicLayouts from 'views/forms-tables/forms/layout/BasicLayouts';

// ==============================|| LAYOUTS - BASIC ||============================== //

function Layouts() {
  return <BasicLayouts />;
}

export default Layouts;
