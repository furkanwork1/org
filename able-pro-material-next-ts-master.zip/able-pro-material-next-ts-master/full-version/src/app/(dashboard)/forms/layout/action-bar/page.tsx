// PROJECT IMPORTS
import ActionBarPage from 'views/forms-tables/forms/layout/ActionBar';

// ==============================|| LAYOUTS- ACTION BAR ||============================== //

function ActionBar() {
  return <ActionBarPage />;
}

export default ActionBar;
