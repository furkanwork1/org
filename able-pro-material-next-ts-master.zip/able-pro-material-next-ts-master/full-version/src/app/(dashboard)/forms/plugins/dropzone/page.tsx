// PROJECT IMPORTS
import DropzonePage from 'views/forms-tables/forms/plugins/DropzonePage';

// ==============================|| PLUGIN - DROPZONE ||============================== //

const Dropzone = () => {
  return <DropzonePage />;
};

export default Dropzone;
