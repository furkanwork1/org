// PROJECT IMPORTS
import RecaptchaPage from 'views/forms-tables/forms/plugins/RecaptchaPage';

// ==============================|| PLUGIN - RECAPTCHA ||============================== //

const Recaptcha = () => {
  return <RecaptchaPage />;
};

export default Recaptcha;
