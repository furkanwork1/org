// PROJECT IMPORTS
import MaskPage from 'views/forms-tables/forms/plugins/MaskPage';

// ==============================|| PLUGIN - MASK INPUT ||============================== //

const Mask = () => {
  return <MaskPage />;
};

export default Mask;
