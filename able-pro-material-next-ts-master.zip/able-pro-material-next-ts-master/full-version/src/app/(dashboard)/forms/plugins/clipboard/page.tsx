// PROJECT IMPORTS
import ClipboardPage from 'views/forms-tables/forms/plugins/ClipboardPage';

// ==============================|| PLUGIN - CLIPBOARD ||============================== //

const Clipboard = () => {
  return <ClipboardPage />;
};

export default Clipboard;
