// PROJECT IMPORTS
import EditorPage from 'views/forms-tables/forms/plugins/EditorPage';

// ==============================|| PLUGIN - EDITOR ||============================== //

const Editor = () => {
  return <EditorPage />;
};

export default Editor;
