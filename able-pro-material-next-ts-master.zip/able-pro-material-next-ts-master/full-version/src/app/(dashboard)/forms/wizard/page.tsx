// PROJECT IMPORTS
import FormsWizardPage from 'views/forms-tables/forms/FormsWizard';

// ==============================|| FORMS WIZARD ||============================== //

const FormsWizard = () => {
  return <FormsWizardPage />;
};

export default FormsWizard;
