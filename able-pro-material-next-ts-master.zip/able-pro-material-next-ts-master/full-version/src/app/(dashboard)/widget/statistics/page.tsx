// PROJECT IMPORTS
import WidgetStatistics from 'views/widget/WidgetStatistics';

// ===========================|| WIDGET - STATISTICS ||=========================== //

const Statistics = () => {
  return <WidgetStatistics />;
};

export default Statistics;
