// PROJECT IMPORTS
import WidgetData from 'views/widget/WidgetData';

// ===========================|| WIDGET - DATA ||=========================== //

const Data = () => {
  return <WidgetData />;
};

export default Data;
