// PROJECT IMPORTS
import WidgetChart from 'views/widget/WidgetChart';

// ==============================|| WIDGET - CHARTS ||============================== //

const Chart = () => {
  return <WidgetChart />;
};

export default Chart;
