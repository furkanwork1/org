// PROJECT IMPORTS
import DashboardAnalytics from 'views/dashboard/DashboardAnalytics';

// ==============================|| DASHBOARD - ANALYTICS ||============================== //

const Analytics = () => {
  return <DashboardAnalytics />;
};

export default Analytics;
