// PROJECT IMPORTS
import DashboardDefault from 'views/dashboard/DashboardDefault';

// ==============================|| DASHBOARD - DEFAULT ||============================== //

const Dashboard = () => {
  return <DashboardDefault />;
};

export default Dashboard;
