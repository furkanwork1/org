// PROJECT IMPORTS
import CustomerList from 'views/apps/CustomerList';

// ==============================|| CUSTOMER - LIST ||============================== //

const CustomerListPage = () => {
  return <CustomerList />;
};

export default CustomerListPage;
