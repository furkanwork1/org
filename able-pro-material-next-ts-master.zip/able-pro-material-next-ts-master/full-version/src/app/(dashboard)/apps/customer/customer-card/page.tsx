// PROJECT IMPORTS
import CustomersCard from 'views/apps/CustomersCard';

// ==============================|| CUSTOMER - CARD ||============================== //

const CustomerCardPage = () => {
  return <CustomersCard />;
};

export default CustomerCardPage;
