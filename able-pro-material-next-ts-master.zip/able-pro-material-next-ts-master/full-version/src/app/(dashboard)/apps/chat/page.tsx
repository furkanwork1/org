// PROJECT IMPORTS
import Chat from 'views/apps/Chat';

// ==============================|| APPLICATION - CHAT ||============================== //

const ChatPage = () => {
  return <Chat />;
};

export default ChatPage;
