// PROJECT IMPORTS
import AddNewProduct from 'views/apps/AddNewProduct';

// ==============================|| ECOMMERCE - ADD PRODUCT ||============================== //

function AddNewProductPage() {
  return <AddNewProduct />;
}

export default AddNewProductPage;
