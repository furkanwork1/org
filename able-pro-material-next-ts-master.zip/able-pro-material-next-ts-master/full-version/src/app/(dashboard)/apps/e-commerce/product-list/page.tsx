// PROJECT IMPORTS
import ProductList from 'views/apps/ProductList';

// ==============================|| ECOMMERCE - PRODUCT LIST ||============================== //

const ProductListPage = () => {
  return <ProductList />;
};

export default ProductListPage;
