// PROJECT IMPORTS
import Checkout from 'views/apps/Checkout';

// ==============================|| ECOMMERCE - CHECKOUT ||============================== //

const CheckoutPage = () => {
  return <Checkout />;
};

export default CheckoutPage;
