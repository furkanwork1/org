// PROJECT IMPORTS
import Products from 'views/apps/Products';

// ==============================|| ECOMMERCE - PRODUCTS ||============================== //

const ProductsPage = () => {
  return <Products />;
};

export default ProductsPage;
