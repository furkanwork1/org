// PROJECT IMPORTS
import InvoiceLists from 'views/apps/InvoiceList';

// ==============================|| INVOICE - LIST ||============================== //

const List = () => {
  return <InvoiceLists />;
};
export default List;
