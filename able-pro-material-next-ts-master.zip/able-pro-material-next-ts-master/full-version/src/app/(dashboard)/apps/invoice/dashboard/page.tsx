// PROJECT IMPORTS
import IncoiceDashboard from 'views/apps/IncoiceDashboard';

// ==============================|| INVOICE - DASHBOARD ||============================== //

const Dashboard = () => {
  return <IncoiceDashboard />;
};

export default Dashboard;
