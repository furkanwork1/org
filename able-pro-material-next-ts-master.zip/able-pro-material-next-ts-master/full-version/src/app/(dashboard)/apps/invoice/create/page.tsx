// PROJECT IMPORTS
import InvoiceCreate from 'views/apps/InvoiceCreate';

// ==============================|| INVOICE - CREATE ||============================== //

const Create = () => {
  return <InvoiceCreate />;
};

export default Create;
