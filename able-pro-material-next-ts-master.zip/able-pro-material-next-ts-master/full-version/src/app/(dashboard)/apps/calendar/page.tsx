// PROJECT IMPORTS
import Calendar from 'views/apps/Calendar';

// ==============================|| CALENDAR - MAIN ||============================== //

const CalendarPage = () => {
  return <Calendar />;
};

export default CalendarPage;
