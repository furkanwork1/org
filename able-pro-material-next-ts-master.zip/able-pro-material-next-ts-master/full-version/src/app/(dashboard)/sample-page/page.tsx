// PROJECT IMPORTS
import SamplePagePage from 'views/other/SamplePage';

// ==============================|| SAMPLE PAGE ||============================== //

const SamplePage = () => {
  return <SamplePagePage />;
};

export default SamplePage;
