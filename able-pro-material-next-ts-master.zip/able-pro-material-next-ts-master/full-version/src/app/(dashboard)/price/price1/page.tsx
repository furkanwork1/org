// PROJECT IMPORTS
import Pricing1Page from 'views/price/Pricing1';

// ==============================|| PRICING ||============================== //

const Pricing = () => {
  return <Pricing1Page />;
};

export default Pricing;
