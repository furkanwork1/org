// PROJECT IMPORTS
import Pricing2Page from 'views/price/Pricing2';

// ==============================|| PRICING ||============================== //

const Pricing = () => {
  return <Pricing2Page />;
};

export default Pricing;
