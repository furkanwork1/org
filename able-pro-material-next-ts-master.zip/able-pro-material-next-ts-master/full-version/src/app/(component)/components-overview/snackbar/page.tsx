// PROJECT IMPORTS
import ComponentSnackbar from 'views/components-overview/ComponentSnackbar';

// ==============================|| COMPONENTS - SNACKBAR ||============================== //

const ComponentSnackbarPage = () => {
  return <ComponentSnackbar />;
};

export default ComponentSnackbarPage;
