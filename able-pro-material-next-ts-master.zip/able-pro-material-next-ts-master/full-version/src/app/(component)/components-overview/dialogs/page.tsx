// PROJECT IMPORTS
import ComponentDialogs from 'views/components-overview/ComponentDialogs';

// ==============================|| COMPONENTS - DIALOGS ||============================== //

const DialogsPage = () => {
  return <ComponentDialogs />;
};

export default DialogsPage;
