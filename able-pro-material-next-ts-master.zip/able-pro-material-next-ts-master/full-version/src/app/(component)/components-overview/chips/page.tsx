// PROJECT IMPORTS
import ComponentChip from 'views/components-overview/ComponentChip';

// ==============================|| COMPONENTS - CHIPS ||============================== //

const ComponentChipPage = () => {
  return <ComponentChip />;
};

export default ComponentChipPage;
