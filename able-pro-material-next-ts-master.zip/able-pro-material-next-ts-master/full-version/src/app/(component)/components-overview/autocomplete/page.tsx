// PROJECT IMPORTS
import ComponentAutocomplete from 'views/components-overview/ComponentAutocomplete';

// ==============================|| COMPONENTS - AUTOCOMPLETE ||============================== //

const ComponentAutocompletePage = () => {
  return <ComponentAutocomplete />;
};

export default ComponentAutocompletePage;
