// PROJECT IMPORTS
import ComponentAccordion from 'views/components-overview/ComponentAccordion';

// ==============================|| COMPONENTS - ACCORDION ||============================== //

const ComponentAccordionPage = () => {
  return <ComponentAccordion />;
};

export default ComponentAccordionPage;
