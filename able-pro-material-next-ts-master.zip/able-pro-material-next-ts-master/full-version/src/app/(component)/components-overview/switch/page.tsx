// PROJECT IMPORTS
import ComponentSwitch from 'views/components-overview/ComponentSwitch';

// ==============================|| COMPONENTS - SWITCH ||============================== //

const ComponentSwitchPage = () => {
  return <ComponentSwitch />;
};

export default ComponentSwitchPage;
