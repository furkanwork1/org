// PROJECT IMPORTS
import ComponentColor from 'views/components-overview/ComponentColor';

// ===============================|| COMPONENTS - COLOR ||=============================== //

const ComponentColorPage = () => {
  return <ComponentColor />;
};

export default ComponentColorPage;
