// PROJECT IMPORTS
import ComponentSlider from 'views/components-overview/ComponentSlider';

// ==============================|| COMPONENTS - SLIDER ||============================== //

const ComponentSliderPage = () => {
  return <ComponentSlider />;
};

export default ComponentSliderPage;
