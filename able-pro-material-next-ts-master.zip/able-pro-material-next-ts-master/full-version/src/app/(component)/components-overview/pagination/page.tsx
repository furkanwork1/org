// PROJECT IMPORTS
import ComponentPagination from 'views/components-overview/ComponentPagination';

// ==============================|| COMPONENTS - PAGINATION ||============================== //

const ComponentPaginationPage = () => {
  return <ComponentPagination />;
};

export default ComponentPaginationPage;
