// PROJECT IMPORTS
import ComponentModal from 'views/components-overview/ComponentModal';

// ==============================|| COMPONENTS - MODAL ||============================== //

const ComponentModalPage = () => {
  return <ComponentModal />;
};

export default ComponentModalPage;
