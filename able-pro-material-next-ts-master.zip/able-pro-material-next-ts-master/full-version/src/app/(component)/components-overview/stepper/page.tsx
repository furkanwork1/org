// PROJECT IMPORTS
import ComponentStepper from 'views/components-overview/ComponentStepper';

// ==============================|| COMPONENTS - STEPPER ||============================== //

const ComponentStepperPage = () => {
  return <ComponentStepper />;
};

export default ComponentStepperPage;
