// PROJECT IMPORTS
import ComponentProgress from 'views/components-overview/ComponentProgress';

// ==============================|| COMPONENTS - PROGRESS ||============================== //

const ComponentProgressPage = () => {
  return <ComponentProgress />;
};

export default ComponentProgressPage;
