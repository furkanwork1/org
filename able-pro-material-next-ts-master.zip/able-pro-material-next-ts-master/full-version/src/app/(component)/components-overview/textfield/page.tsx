// PROJECT IMPORTS
import ComponentTextField from 'views/components-overview/ComponentTextField';

// ==============================|| COMPONENTS - TEXT FEILD ||============================== //

const ComponentTextFieldPage = () => {
  return <ComponentTextField />;
};

export default ComponentTextFieldPage;
