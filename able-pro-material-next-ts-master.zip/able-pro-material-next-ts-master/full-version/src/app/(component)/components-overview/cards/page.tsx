// PROJECT IMPORTS
import ComponentCard from 'views/components-overview/ComponentCard';

// ==============================|| COMPONENTS - CARD ||============================== //

const ComponentCardPage = () => {
  return <ComponentCard />;
};

export default ComponentCardPage;
