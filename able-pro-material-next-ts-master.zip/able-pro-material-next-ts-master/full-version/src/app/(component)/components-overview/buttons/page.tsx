// PROJECT IMPORTS
import ComponentButtons from 'views/components-overview/ComponentButtons';

// ==============================|| COMPOENETS - BUTTON ||============================== //

const ButtonsPage = () => {
  return <ComponentButtons />;
};

export default ButtonsPage;
