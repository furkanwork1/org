// PROJECT IMPORTS
import ComponentAlert from 'views/components-overview/ComponentAlert';

// ==============================|| COMPONENTS - ALERTS ||============================== //

const ComponentAlertPage = () => {
  return <ComponentAlert />;
};

export default ComponentAlertPage;
