// PROJECT IMPORTS
import ComponentRadio from 'views/components-overview/ComponentRadio';

// ==============================|| COMPONENTS - RADIO ||============================== //

const ComponentRadioPage = () => {
  return <ComponentRadio />;
};

export default ComponentRadioPage;
