// PROJECT IMPORTS
import ComponentShadow from 'views/components-overview/ComponentShadow';

// ============================|| COMPONENTS - SHADOW ||============================ //

const ComponentShadowPage = () => {
  return <ComponentShadow />;
};

export default ComponentShadowPage;
