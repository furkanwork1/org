// PROJECT IMPORTS
import ComponentSelect from 'views/components-overview/ComponentSelect';

// ==============================|| COMPONENTS - SELECT ||============================== //

const ComponentSelectPage = () => {
  return <ComponentSelect />;
};

export default ComponentSelectPage;
