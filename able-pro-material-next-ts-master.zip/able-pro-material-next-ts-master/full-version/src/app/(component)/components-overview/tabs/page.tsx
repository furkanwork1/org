// PROJECT IMPORTS
import ComponentTabs from 'views/components-overview/ComponentTabs';

// ==============================|| COMPONENTS - TABS ||============================== //

const ComponentTabsPage = () => {
  return <ComponentTabs />;
};

export default ComponentTabsPage;
