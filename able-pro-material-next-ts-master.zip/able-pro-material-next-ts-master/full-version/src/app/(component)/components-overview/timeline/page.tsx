// PROJECT IMPORTS
import ComponentTimeline from 'views/components-overview/ComponentTimeline';

// ==============================|| COMPONENTS - TIMELINE ||============================== //

const ComponentTimelinePage = () => {
  return <ComponentTimeline />;
};

export default ComponentTimelinePage;
