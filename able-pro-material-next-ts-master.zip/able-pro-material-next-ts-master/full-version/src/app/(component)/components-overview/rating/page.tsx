// PROJECT IMPORTS
import ComponentRating from 'views/components-overview/ComponentRating';

// ==============================|| COMPONENTS - RATING ||============================== //

const ComponentRatingPage = () => {
  return <ComponentRating />;
};

export default ComponentRatingPage;
