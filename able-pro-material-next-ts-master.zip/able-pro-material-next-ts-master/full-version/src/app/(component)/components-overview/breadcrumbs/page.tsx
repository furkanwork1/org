// PROJECT IMPORTS
import ComponentBreadcrumb from 'views/components-overview/ComponentBreadcrumb';

// ==============================|| COMPONENTS - BREADCRUMBS ||============================== //

const ComponentBreadcrumbPage = () => {
  return <ComponentBreadcrumb />;
};

export default ComponentBreadcrumbPage;
