// PROJECT IMPORTS
import ComponentDateTimePicker from 'views/components-overview/ComponentDateTimePicker';

// ===============================|| COMPONENTS - DATE / TIME PICKER ||=============================== //

const ComponentDateTimePickerPage = () => {
  return <ComponentDateTimePicker />;
};

export default ComponentDateTimePickerPage;
