// PROJECT IMPORTS
import ComponentAvatar from 'views/components-overview/ComponentAvatar';

// ==============================|| COMPONENTS - AVATAR ||============================== //

const ComponentAvatarPage = () => {
  return <ComponentAvatar />;
};

export default ComponentAvatarPage;
