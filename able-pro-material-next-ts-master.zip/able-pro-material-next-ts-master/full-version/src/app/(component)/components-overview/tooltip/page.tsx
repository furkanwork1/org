// PROJECT IMPORTS
import ComponentTooltip from 'views/components-overview/ComponentTooltip';

// ==============================|| COMPONENTS - TOOLTIP ||============================== //

const ComponentTooltipPage = () => {
  return <ComponentTooltip />;
};

export default ComponentTooltipPage;
