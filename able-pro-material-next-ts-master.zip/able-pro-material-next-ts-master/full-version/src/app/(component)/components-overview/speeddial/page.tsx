// PROJECT IMPORTS
import ComponentSpeeddial from 'views/components-overview/ComponentSpeeddial';

// ==============================|| COMPONENTS - SPEED DIAL ||============================== //

const ComponentSpeeddialPage = () => {
  return <ComponentSpeeddial />;
};

export default ComponentSpeeddialPage;
