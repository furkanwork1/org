// PROJECT IMPORTS
import ComponentBadge from 'views/components-overview/ComponentBadge';

// ==============================|| COMPONENTS - BADGES ||============================== //

const ComponentBadgePage = () => {
  return <ComponentBadge />;
};

export default ComponentBadgePage;
