// PROJECT IMPORTS
import ComponentTypography from 'views/components-overview/ComponentTypography';

// ==============================|| COMPONENTS - TYPOGRAPHY ||============================== //

const ComponentTypographyPage = () => {
  return <ComponentTypography />;
};

export default ComponentTypographyPage;
