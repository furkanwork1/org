// PROJECT IMPORTS
import ComponentList from 'views/components-overview/ComponentList';

// ==============================|| COMPONENTS - LIST ||============================== //

const ComponentListPage = () => {
  return <ComponentList />;
};

export default ComponentListPage;
