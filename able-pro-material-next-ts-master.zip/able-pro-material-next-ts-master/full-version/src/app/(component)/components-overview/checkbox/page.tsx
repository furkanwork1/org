// PROJECT IMPORTS
import ComponentCheckbox from 'views/components-overview/ComponentCheckbox';

// ==============================|| COMPONENTS - CHECKBOX ||============================== //

const ComponentCheckboxPage = () => {
  return <ComponentCheckbox />;
};

export default ComponentCheckboxPage;
