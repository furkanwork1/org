// PROJECT IMPORTS
import ForgotPassword from 'views/authentication/ForgotPassword';

// ================================|| FORGOT PASSWORD ||================================ //

const ForgotPasswordPage = () => {
  return <ForgotPassword />;
};

export default ForgotPasswordPage;
