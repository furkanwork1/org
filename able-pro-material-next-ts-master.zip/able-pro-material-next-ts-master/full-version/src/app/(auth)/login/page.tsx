// PROJECT IMPORTS
import Login from 'views/authentication/Login';

// ================================|| LOGIN ||================================ //

const LoginPage = () => {
  return <Login />;
};

export default LoginPage;
