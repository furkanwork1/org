// PROJECT IMPORTS
import CheckMail from 'views/authentication/CheckMail';

// ================================|| CHECK MAIL ||================================ //

const CheckMailPage = () => {
  return <CheckMail />;
};

export default CheckMailPage;
