// PROJECT IMPORTS
import Register from 'views/authentication/Register';

// ================================|| REGISTER ||================================ //

const RegisterPage = () => {
  return <Register />;
};

export default RegisterPage;
