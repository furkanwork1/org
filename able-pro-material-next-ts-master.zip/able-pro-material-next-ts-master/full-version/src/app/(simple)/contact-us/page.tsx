// PROJECT IMPORTS
import ContactUSPage from 'views/contact-us/ContactUS';

// ==============================|| CONTACT US - MAIN ||============================== //

function contactUS() {
  return <ContactUSPage />;
}

export default contactUS;
